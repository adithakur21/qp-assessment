package com.example.grocerybooking.controller;

import com.example.grocerybooking.model.GroceryItem;
import com.example.grocerybooking.service.GroceryItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/admin/grocery-items")
public class GroceryItemController {
    @Autowired
    private GroceryItemService service;

    // Get all grocery items
    @GetMapping
    public List<GroceryItem> getAllItems() {
        return service.getAllItems();
    }

    // Add a new grocery item
    @PostMapping
    public GroceryItem addItem(@RequestBody GroceryItem item) {
        return service.addItem(item);
    }

    // Update an existing grocery item
    @PutMapping("/{id}")
    public ResponseEntity<GroceryItem> updateItem(@PathVariable Long id, @RequestBody GroceryItem itemDetails) {
        GroceryItem updatedItem = service.updateItem(id, itemDetails);
        if (updatedItem != null) {
            return ResponseEntity.ok(updatedItem);
        }
        return ResponseEntity.notFound().build();
    }

    // Delete a grocery item
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteItem(@PathVariable Long id) {
        service.deleteItem(id);
        return ResponseEntity.noContent().build();
    }

    // Get a grocery item by ID
    @GetMapping("/{id}")
    public ResponseEntity<GroceryItem> getItemById(@PathVariable Long id) {
        Optional<GroceryItem> item = service.getItemById(id);
        return item.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
}
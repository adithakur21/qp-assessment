package com.example.grocerybooking.service;

import com.example.grocerybooking.model.GroceryItem;
import com.example.grocerybooking.repository.GroceryItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GroceryItemService {
    @Autowired
    private GroceryItemRepository repository;

    // Get all grocery items
    public List<GroceryItem> getAllItems() {
        return repository.findAll();
    }

    // Add a new grocery item
    public GroceryItem addItem(GroceryItem item) {
        return repository.save(item);
    }

    // Update an existing grocery item
    public GroceryItem updateItem(Long id, GroceryItem itemDetails) {
        Optional<GroceryItem> optionalItem = repository.findById(id);
        if (optionalItem.isPresent()) {
            GroceryItem item = optionalItem.get();
            item.setName(itemDetails.getName());
            item.setPrice(itemDetails.getPrice());
            item.setInventory(itemDetails.getInventory());
            return repository.save(item);
        }
        return null; // or throw an exception
    }

    // Delete a grocery item
    public void deleteItem(Long id) {
        repository.deleteById(id);
    }

    // Find a grocery item by ID
    public Optional<GroceryItem> getItemById(Long id) {
        return repository.findById(id);
    }
}
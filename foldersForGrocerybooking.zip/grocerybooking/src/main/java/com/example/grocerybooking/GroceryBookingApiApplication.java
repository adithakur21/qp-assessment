package com.example.grocerybooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroceryBookingApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroceryBookingApiApplication.class, args);
	}

}
